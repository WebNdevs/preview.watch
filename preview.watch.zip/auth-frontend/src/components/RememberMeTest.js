'use client';

import { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';

export default function RememberMeTest() {
  const { getCurrentStoragePreference, clearAllStorage } = useAuth();
  const [storageState, setStorageState] = useState({});
  const [testResults, setTestResults] = useState([]);

  const updateStorageState = () => {
    const rememberMe = getCurrentStoragePreference();
    const localToken = localStorage.getItem('auth_token');
    const localUser = localStorage.getItem('user');
    const localRemember = localStorage.getItem('remember_me');
    const sessionToken = sessionStorage.getItem('auth_token');
    const sessionUser = sessionStorage.getItem('user');

    setStorageState({
      rememberMe,
      localStorage: {
        token: localToken ? `${localToken.substring(0, 20)}...` : 'null',
        user: localUser ? JSON.parse(localUser).email : 'null',
        rememberMe: localRemember
      },
      sessionStorage: {
        token: sessionToken ? `${sessionToken.substring(0, 20)}...` : 'null',
        user: sessionUser ? JSON.parse(sessionUser).email : 'null'
      }
    });
  };

  useEffect(() => {
    updateStorageState();
    
    // Update storage state when storage changes
    const handleStorageChange = () => updateStorageState();
    window.addEventListener('storage', handleStorageChange);
    
    return () => window.removeEventListener('storage', handleStorageChange);
  }, []);

  const addTestResult = (message, type = 'info') => {
    const timestamp = new Date().toLocaleTimeString();
    setTestResults(prev => [...prev, { message, type, timestamp }]);
  };

  const testRememberMeLogic = () => {
    addTestResult('Testing Remember Me logic...', 'info');
    
    try {
      // Test 1: Check current state
      const currentRememberMe = getCurrentStoragePreference();
      addTestResult(`Current Remember Me preference: ${currentRememberMe}`, 'info');
      
      // Test 2: Simulate login with remember me enabled
      const testToken = 'test_token_remember_me_enabled';
      const testUser = { id: 1, email: 'test@example.com', role: 'client' };
      
      localStorage.setItem('auth_token', testToken);
      localStorage.setItem('user', JSON.stringify(testUser));
      localStorage.setItem('remember_me', 'true');
      
      addTestResult('Simulated login with Remember Me enabled', 'success');
      updateStorageState();
      
      // Test 3: Simulate login with remember me disabled
      setTimeout(() => {
        clearAllStorage();
        
        sessionStorage.setItem('auth_token', 'test_token_remember_me_disabled');
        sessionStorage.setItem('user', JSON.stringify({ id: 2, email: 'test2@example.com', role: 'client' }));
        
        addTestResult('Simulated login with Remember Me disabled', 'success');
        updateStorageState();
        
        // Test 4: Clear and restore
        setTimeout(() => {
          clearAllStorage();
          addTestResult('All storage cleared', 'info');
          updateStorageState();
        }, 1000);
      }, 1000);
      
    } catch (error) {
      addTestResult(`Error during test: ${error.message}`, 'error');
    }
  };

  const testStoragePersistence = () => {
    addTestResult('Testing storage persistence...', 'info');
    
    try {
      // Test localStorage persistence
      localStorage.setItem('test_persistent', 'persistent_value');
      addTestResult('Value stored in localStorage', 'success');
      
      // Test sessionStorage (should be cleared on page refresh)
      sessionStorage.setItem('test_session', 'session_value');
      addTestResult('Value stored in sessionStorage', 'success');
      
      addTestResult('localStorage persists across browser restarts, sessionStorage does not', 'info');
      
    } catch (error) {
      addTestResult(`Error during persistence test: ${error.message}`, 'error');
    }
  };

  const clearTestResults = () => {
    setTestResults([]);
  };

  return (
    <div className="max-w-4xl mx-auto p-6 bg-white rounded-lg shadow-lg">
      <h2 className="text-2xl font-bold mb-6 text-gray-800">Remember Me Functionality Test</h2>
      
      {/* Current Storage State */}
      <div className="mb-6 p-4 bg-gray-50 rounded-lg">
        <h3 className="text-lg font-semibold mb-3 text-gray-700">Current Storage State</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <h4 className="font-medium text-gray-600">localStorage</h4>
            <div className="text-sm space-y-1">
              <div>Token: {storageState.localStorage?.token || 'null'}</div>
              <div>User: {storageState.localStorage?.user || 'null'}</div>
              <div>Remember Me: {storageState.localStorage?.rememberMe || 'false'}</div>
            </div>
          </div>
          <div>
            <h4 className="font-medium text-gray-600">sessionStorage</h4>
            <div className="text-sm space-y-1">
              <div>Token: {storageState.sessionStorage?.token || 'null'}</div>
              <div>User: {storageState.sessionStorage?.user || 'null'}</div>
            </div>
          </div>
        </div>
        <div className="mt-3 text-sm text-gray-500">
          Remember Me Preference: <span className="font-medium">{storageState.rememberMe ? 'Enabled' : 'Disabled'}</span>
        </div>
      </div>
      
      {/* Test Controls */}
      <div className="mb-6 space-y-3">
        <div className="flex flex-wrap gap-3">
          <button
            onClick={testRememberMeLogic}
            className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
          >
            Test Remember Me Logic
          </button>
          <button
            onClick={testStoragePersistence}
            className="px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 transition-colors"
          >
            Test Storage Persistence
          </button>
          <button
            onClick={clearAllStorage}
            className="px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700 transition-colors"
          >
            Clear All Storage
          </button>
          <button
            onClick={updateStorageState}
            className="px-4 py-2 bg-gray-600 text-white rounded-md hover:bg-gray-700 transition-colors"
          >
            Refresh State
          </button>
        </div>
      </div>
      
      {/* Test Results */}
      <div className="mb-6">
        <div className="flex justify-between items-center mb-3">
          <h3 className="text-lg font-semibold text-gray-700">Test Results</h3>
          <button
            onClick={clearTestResults}
            className="px-3 py-1 text-sm bg-gray-500 text-white rounded hover:bg-gray-600 transition-colors"
          >
            Clear Results
          </button>
        </div>
        <div className="max-h-64 overflow-y-auto space-y-2">
          {testResults.length === 0 ? (
            <div className="text-gray-500 text-center py-4">No test results yet. Run a test to see results.</div>
          ) : (
            testResults.map((result, index) => (
              <div
                key={index}
                className={`p-3 rounded-md text-sm ${
                  result.type === 'error' ? 'bg-red-100 text-red-800' :
                  result.type === 'success' ? 'bg-green-100 text-green-800' :
                  'bg-blue-100 text-blue-800'
                }`}
              >
                <div className="flex justify-between items-start">
                  <span>{result.message}</span>
                  <span className="text-xs opacity-75 ml-2">{result.timestamp}</span>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
      
      {/* Instructions */}
      <div className="p-4 bg-blue-50 rounded-lg">
        <h3 className="text-lg font-semibold mb-2 text-blue-800">How to Test Remember Me</h3>
        <ol className="list-decimal list-inside space-y-1 text-sm text-blue-700">
          <li>Go to the login page and check "Remember Me"</li>
          <li>Login with valid credentials</li>
          <li>Check that data is stored in localStorage (persistent)</li>
          <li>Close and reopen the browser</li>
          <li>Verify you're still logged in</li>
          <li>Try logging in without "Remember Me" checked</li>
          <li>Verify data is stored in sessionStorage (session-only)</li>
          <li>Close and reopen the browser</li>
          <li>Verify you're logged out</li>
        </ol>
      </div>
    </div>
  );
}

