'use client';

import RememberMeTest from '@/components/RememberMeTest';
import { AuthProvider } from '@/contexts/AuthContext';

export default function TestRememberMePage() {
  return (
    <AuthProvider>
      <div className="min-h-screen bg-gray-100 py-8">
        <div className="container mx-auto px-4">
          <h1 className="text-3xl font-bold text-center mb-8 text-gray-800">
            Remember Me Functionality Testing
          </h1>
          <RememberMeTest />
        </div>
      </div>
    </AuthProvider>
  );
}

