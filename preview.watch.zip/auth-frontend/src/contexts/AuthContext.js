'use client';

import { createContext, useContext, useState, useEffect } from 'react';
import api from '@/services/api';

const AuthContext = createContext();

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  // Helper function to get storage based on remember me preference
  const getStorage = (rememberMe) => {
    return rememberMe ? localStorage : sessionStorage;
  };

  // Helper function to clear all storage
  const clearAllStorage = () => {
    localStorage.removeItem('auth_token');
    localStorage.removeItem('user');
    localStorage.removeItem('remember_me');
    sessionStorage.removeItem('auth_token');
    sessionStorage.removeItem('user');
  };

  // Helper function to get current storage preference
  const getCurrentStoragePreference = () => {
    return localStorage.getItem('remember_me') === 'true';
  };

  useEffect(() => {
    const initializeAuth = async () => {
      try {
        // Check if we have authentication data
        const rememberMe = getCurrentStoragePreference();
        const storage = getStorage(rememberMe);
        
        const token = storage.getItem('auth_token');
        const userData = storage.getItem('user');
        
        if (token && userData) {
          try {
            const user = JSON.parse(userData);
            setUser(user);
            
            // Ensure data is in the correct storage
            if (rememberMe) {
              // Move to localStorage if not already there
              if (storage !== localStorage) {
                localStorage.setItem('auth_token', token);
                localStorage.setItem('user', userData);
                localStorage.setItem('remember_me', 'true');
                sessionStorage.removeItem('auth_token');
                sessionStorage.removeItem('user');
              }
            } else {
              // Move to sessionStorage if not already there
              if (storage !== sessionStorage) {
                sessionStorage.setItem('auth_token', token);
                sessionStorage.setItem('user', userData);
                localStorage.removeItem('auth_token');
                localStorage.removeItem('user');
                localStorage.removeItem('remember_me');
              }
            }
            
            console.log('Authentication state restored:', { 
              user: user.email, 
              rememberMe,
              storage: rememberMe ? 'localStorage' : 'sessionStorage'
            });
          } catch (error) {
            console.error('Error parsing user data:', error);
            clearAllStorage();
          }
        } else {
          console.log('No authentication data found');
        }
      } catch (error) {
        console.error('Error initializing auth:', error);
        clearAllStorage();
      } finally {
        setLoading(false);
      }
    };

    initializeAuth();
  }, []);

  const login = async (email, password, rememberMe = false) => {
    try {
      console.log('Login attempt:', { email, rememberMe });
      
      // First, get CSRF cookie from Laravel
      await api.get('/sanctum/csrf-cookie');
      
      const response = await api.post('/login', { 
        email, 
        password, 
        remember_me: rememberMe 
      });
      
      const { user, token } = response.data;
      
      console.log('Login response received:', { 
        user: user.email, 
        tokenLength: token.length,
        rememberMe 
      });
      
      // Clear any existing data first
      clearAllStorage();
      
      // Store data in appropriate storage
      const storage = getStorage(rememberMe);
      storage.setItem('auth_token', token);
      storage.setItem('user', JSON.stringify(user));
      
      // Set remember me flag in localStorage for persistence
      if (rememberMe) {
        localStorage.setItem('remember_me', 'true');
      }
      
      setUser(user);
      
      console.log('Login successful, data stored in:', 
        rememberMe ? 'localStorage (persistent)' : 'sessionStorage (session-only)'
      );
      
      return { success: true, user };
    } catch (error) {
      console.error('Login error:', error);
      return {
        success: false,
        message: error.response?.data?.message || 'Login failed'
      };
    }
  };

  const register = async (name, email, password, password_confirmation, role = 'client', rememberMe = false) => {
    try {
      // First, get CSRF cookie from Laravel
      await api.get('/sanctum/csrf-cookie');
      
      const response = await api.post('/register', {
        name,
        email,
        password,
        password_confirmation,
        role,
        remember_me: rememberMe
      });
      
      const { user, token } = response.data;
      
      // Clear any existing data first
      clearAllStorage();
      
      // Store data in appropriate storage
      const storage = getStorage(rememberMe);
      storage.setItem('auth_token', token);
      storage.setItem('user', JSON.stringify(user));
      
      // Set remember me flag in localStorage for persistence
      if (rememberMe) {
        localStorage.setItem('remember_me', 'true');
      }
      
      setUser(user);
      
      return { success: true, user };
    } catch (error) {
      return {
        success: false,
        message: error.response?.data?.message || 'Registration failed',
        errors: error.response?.data?.errors
      };
    }
  };

  const logout = async () => {
    try {
      await api.post('/logout');
    } catch (error) {
      console.error('Logout error:', error);
    } finally {
      clearAllStorage();
      setUser(null);
    }
  };

  const forgotPassword = async (email) => {
    try {
      // Get CSRF cookie first
      await api.get('/sanctum/csrf-cookie');
      
      const response = await api.post('/forgot-password', { email });
      return {
        success: true,
        message: response.data.message
      };
    } catch (error) {
      return {
        success: false,
        message: error.response?.data?.message || 'Failed to send reset link'
      };
    }
  };

  const resetPassword = async (email, token, password, password_confirmation) => {
    try {
      // Get CSRF cookie first
      await api.get('/sanctum/csrf-cookie');
      
      const response = await api.post('/reset-password', {
        email,
        token,
        password,
        password_confirmation
      });
      return {
        success: true,
        message: response.data.message
      };
    } catch (error) {
      return {
        success: false,
        message: error.response?.data?.message || 'Password reset failed',
        errors: error.response?.data?.errors
      };
    }
  };

  const isAuthenticated = !!user;
  const isAdmin = user?.role === 'admin';
  const isAgency = user?.role === 'agency';
  const isClient = user?.role === 'client';

  const value = {
    user,
    loading,
    login,
    register,
    logout,
    forgotPassword,
    resetPassword,
    isAuthenticated,
    isAdmin,
    isAgency,
    isClient,
    // Add helper functions for testing
    getCurrentStoragePreference,
    clearAllStorage
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};